// pages/new/new.js
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        isImg : false,
        task_name : '',
        task_startTime : '',
        task_endTime : '',
        task_detail : '',
        task_img : '',
        user_avatarUrl : '',
        timeValue : '选择任务开始时间'
    },

/**
 * 自定义函数--获取任务内容 
 */
getTask_detail(e){
    this.setData({
        task_detail : e.detail.value
    })
},

/**
 * 自定义函数--获取任务名称 
 */
    getTask_name(e){
        this.setData({
            task_name : e.detail.value
        })
    },
/**
 * 自定义函数--添加协作成员
 */
    add_user(){
        wx.navigateTo({
          url: '/pages/friends/friends'
        })
    },
/**
 * 自定义函数--获取用户上传图片
 */
    getImg(){
        let that = this;
        wx.chooseMedia({
          count:1,
          mediaType : ['image', 'video'],
          sourceType : ['album', 'camera'],
          maxDuration : 60,
          success : function(res){
              that.setData({
                task_img : res.tempFiles[0].tempFilePath,
                isImg : true
              })
          }
        })
    },

/**
 * 点击预览图片
 */
    previewImg(){
        let that = this;
        wx.previewImage({
            current : that.data.task_img,
            urls: [that.data.task_img]
        })
    },
/**
 * 自定义函数--添加任务 
 */
   makeSure(){
    if(Object.keys(this.data.task_name).length > 0){ //判断是否输入任务
        let pages = getCurrentPages();//获取当前页面js里面的pages里的所有信息
       let prevPage = pages[ pages.length - 2];//prevPage 是获取上一个页面的js里面的pages的所有信息。
       let e = this.data;
       getApp().globalData.taskNum += 1; 
       prevPage.setData({
            task_name : e.task_name,
            task_startTime : e.task_startTime,
            task_endTime : e.task_endTime,
            task_detail : e.task_detail,
            task_img : e.task_img,
            user_avatarUrl : e.user_avatarUrl
       })
       prevPage.onLoad();
       wx.navigateBack({
         delta: 1,
       })
    }
    else if (Object.keys(this.data.task_name).length == 0){
        wx.showToast({
          title: '不能新建空任务哦~',
          icon : 'none',
          duration : 2000
        })
    }
   },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        var User_url = wx.getStorageSync("user_url")
        this.setData({
            user_avatarUrl : User_url
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})