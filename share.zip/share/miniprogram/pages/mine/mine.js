
Page({

    /**
     * 页面的初始数据
     */
    data: {
        isLogin : false,
        src : '/images/用户.png',
        Nickname : '未授权用户',
        gender : '',
        gender_src :''
    },
    //更改用户状态
    changeStatus(e){
        let that = this;
        wx.showModal({
            content : '是否退出登录',
            success : function(res){
                if(res.confirm){
                    that.setData({
                        isLogin : false,
                        src : '/images/用户.png',
                        Nickname : '未授权用户'
                    })
                }
            }
        })
    },
    //获取用户信息
    getUserProfile(e) {
        wx.getUserProfile({
          desc: '展示用户信息', 
          success: (res) => {
            let info = res.userInfo;
            wx.setStorageSync("user_url", info.avatarUrl);
            this.setData({
               src:info.avatarUrl,
               Nickname: info.nickName,
               isLogin : true,
               gender : info.gender
            })
          }
        })
        if(this.data.gender == '1'){
            this.setData({
                gender_src : '/images/女性.png'
            })
        }
        else{
            this.setData({
                gender_src : '/images/男性.png'
            })
        }
      },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})