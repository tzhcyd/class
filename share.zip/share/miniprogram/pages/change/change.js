// pages/change/change.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        datalist : {
            task_name : '',
            task_startTime : '',
            task_endTime : '',
            task_detail : '',
            task_img : '',
            user_avatarUrl : '',
            task_index : 0
        },
        isImg : false,
    },
/**
 * 自定义函数--获取任务名称 
 */
changeTask_name(e){
    let taskName = 'datalist.task_name'
    this.setData({
        [taskName] : e.detail.value
    })
},
/**
 * 自定义函数--添加协作成员
 */
add_user(){
    wx.navigateTo({
      url: '/pages/friends/friends'
    })
},
/**
 * 自定义函数--修改任务内容 
 */
changeTask_detail(e){
    let taskDetail = 'datalist.task_detail'
    this.setData({
        [taskDetail] : e.detail.value
    })
},
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        let list = JSON.parse(options.dataList)
        this.setData({
            datalist : list
        })
        if(Object.keys(this.data.datalist.task_detail).length == 0){
            let taskDetail = 'datalist.task_detail'
            this.setData({
                [taskDetail] : '暂时还没有内容哦~快去添加任务内容吧~'
            })
        }
        if(Object.keys(this.data.datalist.task_img).length > 0){
            this.setData({
                isImg : true
            })
        }
    },
/**
 * 点击预览图片
 */
previewImg(){
    let that = this;
    wx.previewImage({
        current : that.data.datalist.task_img,
        urls: [that.data.datalist.task_img]
    })
},
/**
 * 自定义函数--添加任务 
 */
makeSure(){
       let pages = getCurrentPages();//获取当前页面js里面的pages里的所有信息
        //修改主页信息
        let PrevPage = pages[ pages.length - 3];
        let E = this.data.datalist;
        PrevPage.setData({
            [`list[${E.task_index}].task_name`] : E.task_name,
            [`list[${E.task_index}].task_startTime`] : E.task_startTime,
            [`list[${E.task_index}].task_endTime`] : E.task_endTime,
            [`list[${E.task_index}].task_detail`] : E.task_detail,
            [`list[${E.task_index}].task_img`] : E.task_img,
            [`list[${E.task_index}].user_avatarUrl`] : E.user_avatarUrl,
        })
        PrevPage.onLoad();
       
        //修改上一页面信息
       let prevPage = pages[ pages.length - 2];//prevPage 是获取上一个页面的js里面的pages的所有信息。
       let e = this.data.datalist;
       prevPage.setData({
            task_name : e.task_name,
            task_startTime : e.task_startTime,
            task_endTime : e.task_endTime,
            task_detail : e.task_detail,
            task_img : e.task_img,
            user_avatarUrl : e.user_avatarUrl,
            task_index : e.task_index,
            isChange : true
       })
       if(Object.keys(e.task_detail).length > 0){
           prevPage.setData({
               isDetail : true
           })
       }
       prevPage.onLoad();
       wx.navigateBack({
         delta: 1,
       })
   },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})