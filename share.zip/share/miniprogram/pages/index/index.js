var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    taskNum : 0,
    isTask : false,
    task_name : '',
    task_startTime : '',
    task_endTime : '',
    task_detail : '',
    task_img : '',
    isChange : false,
    user_avatarUrl : '',
    list : []
  },
  /**
 * 自定义函数--点击查看任务详情
 */
getDetail(e){
    var taskIndex = e.currentTarget.dataset.task_index;
    if(!this.data.list[taskIndex].isFinish){
        let dataList = JSON.stringify(this.data.list[taskIndex])
        wx.navigateTo({
            url: "/pages/detail/detail?dataList=" + dataList + "&index=" + taskIndex
      })
    }
    else{
        let dataList = JSON.stringify(this.data.list[taskIndex])
        wx.navigateTo({
            url: "/pages/end/end?dataList=" + dataList
        })
    }
},
/**
 * 自定义函数--点击新建任务
 */
  newTask(){
      wx.navigateTo({
        url: "/pages/new/new"
      })
  },
/**
 * 自定义函数--计时 
 */
  toggleTimer(e){
    let Index = e.currentTarget.dataset.index;
    let nowList = this.data.list[Index];
        if(nowList.buttonText === '开始'){
            this.setData({
              [`list[${Index}].buttonText`] : "暂停",
              [`list[${Index}].buttonColor`] : "#f26b6b",
              [`list[${Index}].Time_img`] : "/images/蓝点_s.png",
              [`list[${Index}].isStart`] : true
            })
            nowList.timer = setInterval(()=>{
                if(!nowList.isFinish){
                    if(!nowList.isPausesd){
                        nowList.seconds++;
                        const time = this.formatTime(nowList.seconds);
                        this.setData({
                            [`list[${Index}].currentTime`] : time
                        });
                    }
                }
            },1000);
        }
        else if(nowList.buttonText === '暂停'){
            clearInterval(nowList.timer);
            this.setData({
                [`list[${Index}].buttonText`] : "继续",
                [`list[${Index}].buttonColor`] : "#3a99f7",
                [`list[${Index}].isPaused`] : true,
                [`list[${Index}].isStart`] : false
            });
        }
        else if(nowList.buttonText === '继续'){
            this.setData({
                [`list[${Index}].buttonText`] : "暂停",
                [`list[${Index}].buttonColor`] : "#f26b6b",
                [`list[${Index}].isPaused`] : false,
                [`list[${Index}].isStart`] : true
            });
            nowList.timer = setInterval(()=>{
                if(!nowList.isPausesd) {
                    if(!nowList.isFinish){
                        nowList.seconds++;
                    const time = this.formatTime(nowList.seconds);
                    this.setData({
                        [`list[${Index}].currentTime`] : time
                    });
                }
            }
        },1000);        
     }
},
  formatTime(seconds){
    const h = Math.floor(seconds / 3600).toString().padStart(2,"0");
    const m = Math.floor((seconds%3600) / 60).toString().padStart(2,"0");
    const s = (seconds %60).toString().padStart(2,"0");
    return `${h}:${m}:${s}`;
  },

  /**
   * 自定义函数--结束任务
   */
  finishTask(e){
    let Index = e.currentTarget.dataset.task_index;
    this.setData({
        [`list[${Index}].buttonText`] : "已完成",
        [`list[${Index}].buttonColor`] : "#707070",
        [`list[${Index}].isPaused`] : true,
        [`list[${Index}].isFinish`] : true,
        [`list[${Index}].isStart`] : true,
        [`list[${Index}].Time_img`] : "/images/12_YJ_C_BI_深灰点_1.png"
    })
},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
        if(app.globalData.taskNum != 0){
            this.setData({
                isTask : true
            })
            if(this.data.taskNum == (app.globalData.taskNum - 1)){
                this.setData({
                    taskNum : app.globalData.taskNum
                })
                let newList = [{
                    task_name : this.data.task_name,
                    task_startTime : this.data.task_startTime,
                    task_endTime : this.data.task_endTime,
                    task_detail : this.data.task_detail,
                    task_img : this.data.task_img,
                    task_index : app.globalData.taskNum - 1,
                    user_avatarUrl : this.data.user_avatarUrl,
                    buttonText : '开始',
                    buttonColor : '#3a99f7',
                    currentTime : '00:00:00',
                    timer : null,
                    isStart : false,
                    isPausesd : false,
                    isFinish : false,
                    seconds : 0,
                    Time_img : '/images/红点.png'
                }];
                this.data.list = this.data.list.concat(newList);
                this.setData({
                    list : this.data.list
                })
            }
        };
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})